Q:- Read and write to a real time database to a server using firebase.


Ans:-

from firebase import firebase


firebase = firebase.FirebaseApplication('URL of Database', None)
data =  { 'Name': 'John Doe',
          'RollNo': 3,
          'Percentage': 70.02
          }
result = firebase.post('/python-example-f6d0b/Students/',data)
print(result)


Retrieving The Data *
from firebase import firebase

firebase = firebase.FirebaseApplication('URL of database', None)
result = firebase.get('/python-example-f6d0b/Students/', '')
print(result)


Updating The Data
from firebase import firebase

firebase = firebase.FirebaseApplication('Database URL', None)
firebase.put('/python-example-f6d0b/Students/-LjLUhaWGuxNd5gOEmse','Name','Bob')
print('Record Updated')


Deleting The Data
from firebase import firebase

firebase = firebase.FirebaseApplication('URL Of Database', None)
firebase.delete('/python-example-f6d0b/Students/', '-LjLUhaWGuxNd5gOEmse')
print('Record Deleted')