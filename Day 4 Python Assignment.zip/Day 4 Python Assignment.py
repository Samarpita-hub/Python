Question 1
Write down a program in Python for Opening a File and Writing " I Love LetsUpgrade" And close
it, and read it back again, and then append some data to it and close it.

Ans:-
    def file_read(fname):
        txt = open(fname)
        print(txt.read())

    file_read('test.txt')



Question 2
Write a function which can return a Factorial of any numbers as INT, given in the argument.
  
Ans:-
    def factorial(num):
    """This is a recursive function that calls
   itself to find the factorial of given number"""
    if num == 1:
        return num
    else:
        return num * factorial(num - 1)


   # We will find the factorial of this number
   num = int(input("Enter a Number: "))

   # if input number is negative then return an error message
   # elif the input number is 0 then display 1 as output
   # else calculate the factorial by calling the user defined function
   if num < 0:
      print("Factorial cannot be found for negative numbers")
  elif num == 0:
      print("Factorial of 0 is 1")
  else:
      print("Factorial of", num, "is: ", factorial(num))